import pygame
import random
import sys

def init_game():
    pygame.init()
    width, height = 800, 600
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption("Space Invader")
    return width, height, screen

def load_assets():
    player_img = pygame.image.load('player.png')
    enemy_img = pygame.image.load('enemy.png')
    bullet_img = pygame.image.load('bullet.png')
    golden_ship_img = pygame.image.load('golden_ship.png')
    bg_img = pygame.image.load('galaxy_background.jpg')
    player_img = pygame.transform.scale(player_img, (50, 50))
    enemy_img = pygame.transform.scale(enemy_img, (50, 50))
    bullet_img = pygame.transform.scale(bullet_img, (10, 30))
    golden_ship_img = pygame.transform.scale(golden_ship_img, (60, 60))
    bg_img = pygame.transform.scale(bg_img, (800, 600))
    return player_img, enemy_img, bullet_img, golden_ship_img, bg_img

def spawn_enemies(num, screen_width):
    enemies = []
    for _ in range(num):
        x = random.randint(0, screen_width - 50)
        y = random.randint(-100, -50)
        enemies.append([x, y])
    return enemies

def load_high_score():
    try:
        with open("high_score.txt", "r") as file:
            return int(file.read())
    except FileNotFoundError:
        return 0

def save_high_score(score):
    with open("high_score.txt", "w") as file:
        file.write(str(score))

def draw_text(screen, text, font, color, x, y):
    text_surface = font.render(text, True, color)
    screen.blit(text_surface, (x, y))

def draw_button(screen, text, font, color, x, y, width, height):
    pygame.draw.rect(screen, color, pygame.Rect(x, y, width, height))
    draw_text(screen, text, font, (255, 255, 255), x + 10, y + 10)

def show_menu(screen, bg_img):
    font = pygame.font.Font(None, 74)
    small_font = pygame.font.Font(None, 36)
    while True:
        screen.blit(bg_img, (0, 0))
        draw_text(screen, "Space Invader", font, (255, 255, 255), 150, 100)
        draw_button(screen, "Play Game", small_font, (0, 128, 0), 300, 250, 200, 50)
        draw_button(screen, "Quit", small_font, (128, 0, 0), 300, 320, 200, 50)

        pygame.display.update()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                if 300 < mx < 500 and 250 < my < 300:
                    return
                elif 300 < mx < 500 and 320 < my < 370:
                    pygame.quit()
                    sys.exit()

def show_game_over(screen, score, high_score, bg_img):
    font = pygame.font.Font(None, 74)
    small_font = pygame.font.Font(None, 36)
    while True:
        screen.blit(bg_img, (0, 0))
        draw_text(screen, "Game Over", font, (255, 0, 0), 250, 100)
        draw_text(screen, f"Score: {score}", small_font, (255, 255, 255), 350, 200)
        draw_text(screen, f"High Score: {high_score}", small_font, (255, 255, 255), 300, 250)
        draw_button(screen, "Retry", small_font, (0, 128, 0), 300, 320, 200, 50)
        draw_button(screen, "Quit", small_font, (128, 0, 0), 300, 390, 200, 50)

        pygame.display.update()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                if 300 < mx < 500 and 320 < my < 370:
                    return
                elif 300 < mx < 500 and 390 < my < 440:
                    pygame.quit()
                    sys.exit()

def game_loop():
    width, height, screen = init_game()
    player_img, enemy_img, bullet_img, golden_ship_img, bg_img = load_assets()
    
    player_x, player_y = width // 2, height - 60
    player_speed = int(input("Enter player speed (1-10): "))
    enemy_spawn_interval = int(input("Enter enemy spawn interval (in milliseconds): "))

    bullet_speed = 7
    spawn_limit = 25
    
    enemies = []
    bullets = []
    score = 0
    high_score = load_high_score()
    
    clock = pygame.time.Clock()
    last_enemy_spawn_time = pygame.time.get_ticks()
    golden_ship_spawned = False
    game_over = False

    while not game_over:
        screen.blit(bg_img, (0, 0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    bullets.append([player_x + 20, player_y])
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
        if keys[pygame.K_RIGHT] and player_x < width - 50:
            player_x += player_speed
        
        for bullet in bullets[:]:
            bullet[1] -= bullet_speed
            if bullet[1] < 0:
                bullets.remove(bullet)
        
        for enemy in enemies[:]:
            enemy[0] += random.choice([-1, 1])
            enemy[1] += 2
            if enemy[1] > height:
                enemies.remove(enemy)
            if enemy[0] < player_x < enemy[0] + 50 and enemy[1] < player_y < enemy[1] + 50:
                game_over = True
                break
            for bullet in bullets[:]:
                if enemy[0] < bullet[0] < enemy[0] + 50 and enemy[1] < bullet[1] < enemy[1] + 50:
                    bullets.remove(bullet)
                    enemies.remove(enemy)
                    score += 1
                    break
        
        current_time = pygame.time.get_ticks()
        if len(enemies) < spawn_limit and current_time - last_enemy_spawn_time > enemy_spawn_interval:
            num_to_spawn = random.choice([2, 3])
            enemies.extend(spawn_enemies(num_to_spawn, width))
            last_enemy_spawn_time = current_time
        
        if not golden_ship_spawned and len(enemies) == 0:
            golden_ship_x = random.randint(0, width - 60)
            golden_ship_y = -60
            golden_ship_spawned = True
        
        if golden_ship_spawned:
            golden_ship_y += 5
            if golden_ship_y > height:
                golden_ship_spawned = False
            for bullet in bullets[:]:
                if golden_ship_x < bullet[0] < golden_ship_x + 60 and golden_ship_y < bullet[1] < golden_ship_y + 60:
                    bullets.remove(bullet)
                    score += 10
                    golden_ship_spawned = False
                    break
            if golden_ship_x < player_x < golden_ship_x + 60 and golden_ship_y < player_y < golden_ship_y + 60:
                game_over = True
        
        screen.blit(player_img, (player_x, player_y))
        for bullet in bullets:
            screen.blit(bullet_img, (bullet[0], bullet[1]))
        for enemy in enemies:
            screen.blit(enemy_img, (enemy[0], enemy[1]))
        if golden_ship_spawned:
            screen.blit(golden_ship_img, (golden_ship_x, golden_ship_y))
        
        draw_text(screen, f"Score: {score}", pygame.font.Font(None, 36), (255, 255, 255), 10, 10)
        draw_text(screen, f"High Score: {high_score}", pygame.font.Font(None, 36), (255, 255, 255), 10, 50)
        
        pygame.display.update()
        clock.tick(60)
    
    if score > high_score:
        save_high_score(score)
    
    show_game_over(screen, score, high_score, bg_img)

if __name__ == "__main__":
    while True:
        show_menu(init_game()[2], load_assets()[4])
        game_loop()
